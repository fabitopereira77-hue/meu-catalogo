export interface UserProfile {
  uid: string;
  email: string;
  name: string;
  role: 'rep' | 'client';
  username?: string;
  repId?: string;
}

export interface Catalog {
  id: string;
  repId: string;
  name: string;
  type: 'pdf' | 'excel' | 'image' | 'external';
  fileUrl: string;
  coverUrl?: string;
  logoUrl?: string;
  createdAt: string;
}

export interface Product {
  id: string;
  catalogId: string;
  repId: string;
  name: string;
  price: number;
  brand?: string;
  code?: string;
  description?: string;
  imageUrl?: string;
  category?: string;
  pageNumber?: number;
}

export interface QuoteItem {
  productId: string;
  name: string;
  quantity: number;
  price: number;
  brand?: string;
  code?: string;
}

export interface Quote {
  id: string;
  repId: string;
  repName?: string;
  clientId?: string;
  clientEmail: string;
  clientName?: string;
  items: QuoteItem[];
  total: number;
  status: 'draft' | 'sent' | 'accepted' | 'rejected';
  createdAt: string;
}
