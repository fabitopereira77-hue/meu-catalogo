import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { auth } from '../firebase';
import { BookOpen, Search, FileText, LogOut, User, ExternalLink, Cloud } from 'lucide-react';

export default function Navbar() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await auth.signOut();
    navigate('/login');
  };

  return (
    <nav className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 font-black text-2xl text-navy group">
          <div className="bg-navy text-white p-2 rounded-xl group-hover:rotate-12 transition-transform duration-300">
            <BookOpen className="w-6 h-6" />
          </div>
          <span className="tracking-tighter uppercase">Representação</span>
        </Link>

        <div className="flex items-center gap-10">
          <Link to="/" className="text-gray-500 font-bold hover:text-navy transition-colors text-sm uppercase tracking-widest">
            Início
          </Link>
          <a href="/#catalogos" className="text-gray-500 font-bold hover:text-navy transition-colors text-sm uppercase tracking-widest">
            Catálogos
          </a>
          <a href="/#cotacao" className="text-gray-500 font-bold hover:text-navy transition-colors text-sm uppercase tracking-widest">
            Cotação
          </a>
          
          {profile?.role === 'rep' && (
            <div className="flex items-center gap-8 border-l border-gray-100 pl-8">
              <Link to="/quote" className="text-gray-500 font-bold hover:text-navy transition-colors flex items-center gap-2 text-sm uppercase tracking-widest">
                <FileText className="w-4 h-4" />
                Painel
              </Link>
              <Link to="/cloud" className="text-gray-500 font-bold hover:text-navy transition-colors flex items-center gap-2 text-sm uppercase tracking-widest">
                <Cloud className="w-4 h-4" />
                Nuvem
              </Link>
            </div>
          )}

          {user ? (
            <div className="flex items-center gap-4 ml-4 pl-4 border-l border-gray-200">
              <div className="flex flex-col items-end">
                <span className="text-sm font-semibold text-navy">{profile?.name || user.email}</span>
                <span className="text-[10px] text-gray-500 uppercase tracking-widest">{profile?.role === 'rep' ? 'Representante' : 'Cliente'}</span>
              </div>
              <button
                onClick={handleLogout}
                className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                title="Sair"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              className="bg-navy text-white px-6 py-2.5 rounded-full font-semibold hover:bg-blue-900 transition-all shadow-md"
            >
              Entrar
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
