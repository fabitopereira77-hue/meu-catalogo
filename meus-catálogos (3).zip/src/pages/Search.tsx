import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, orderBy, startAt, endAt } from 'firebase/firestore';
import { db } from '../firebase';
import { Product } from '../types';
import { useSearchParams } from 'react-router-dom';
import { Search as SearchIcon, ShoppingCart, Filter, Package, Info } from 'lucide-react';
import { formatCurrency } from '../lib/utils';
import { toast } from 'sonner';

export default function Search() {
  const [searchParams] = useSearchParams();
  const catalogId = searchParams.get('catalogId');
  const [searchTerm, setSearchTerm] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [cart, setCart] = useState<Record<string, number>>({});

  useEffect(() => {
    const term = searchParams.get('q');
    if (term) {
      setSearchTerm(term);
      fetchProducts(catalogId || undefined, term);
    } else if (catalogId) {
      fetchProducts(catalogId);
    }
  }, [catalogId, searchParams]);

  const fetchProducts = async (cId?: string, term?: string) => {
    setLoading(true);
    try {
      let q = query(collection(db, 'products'));
      
      if (cId) {
        q = query(q, where('catalogId', '==', cId));
      }
      
      const querySnapshot = await getDocs(q);
      const fetchedProducts = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
      
      if (term) {
        const lowerTerm = term.toLowerCase();
        const filtered = fetchedProducts.filter(p => 
          p.name.toLowerCase().includes(lowerTerm) || 
          p.description?.toLowerCase().includes(lowerTerm) ||
          p.brand?.toLowerCase().includes(lowerTerm) ||
          p.code?.toLowerCase().includes(lowerTerm)
        );
        setProducts(filtered);
      } else {
        setProducts(fetchedProducts);
      }
    } catch (error) {
      console.error(error);
      toast.error('Erro ao buscar produtos.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchProducts(catalogId || undefined, searchTerm);
  };

  const addToCart = (product: Product) => {
    setCart(prev => ({
      ...prev,
      [product.id]: (prev[product.id] || 0) + 1
    }));
    toast.success(`${product.name} adicionado ao orçamento!`);
    
    const currentCart = JSON.parse(localStorage.getItem('quote_cart') || '[]');
    const existing = currentCart.find((item: any) => item.productId === product.id);
    if (existing) {
      existing.quantity += 1;
    } else {
      currentCart.push({
        productId: product.id,
        name: product.name,
        price: product.price,
        quantity: 1,
        brand: product.brand,
        code: product.code
      });
    }
    localStorage.setItem('quote_cart', JSON.stringify(currentCart));
  };

  return (
    <div className="container mx-auto px-4 py-12 space-y-12">
      <div className="bg-navy p-12 rounded-[2rem] shadow-2xl text-white">
        <h1 className="text-4xl font-bold mb-8">Busca Inteligente</h1>
        <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <SearchIcon className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 w-6 h-6" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Digite o nome do produto, código ou marca..."
              className="w-full pl-16 pr-6 py-5 rounded-2xl border-none text-gray-900 focus:ring-4 focus:ring-blue-400 outline-none transition-all text-xl shadow-inner"
            />
          </div>
          <button
            type="submit"
            className="bg-blue-600 text-white px-12 py-5 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-xl text-lg"
          >
            Pesquisar
          </button>
        </form>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {loading ? (
          Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 space-y-4">
              <div className="bg-gray-100 aspect-square rounded-2xl animate-pulse"></div>
              <div className="h-6 bg-gray-100 rounded-lg w-3/4 animate-pulse"></div>
              <div className="h-4 bg-gray-100 rounded-lg w-1/2 animate-pulse"></div>
            </div>
          ))
        ) : products.length > 0 ? (
          products.map((product) => (
            <div key={product.id} className="group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 border border-gray-100 flex flex-col">
              <div className="aspect-square bg-gray-50 relative overflow-hidden flex items-center justify-center p-8">
                <img
                  src={product.imageUrl || `https://picsum.photos/seed/${product.name}/400/400`}
                  alt={product.name}
                  className="max-w-full max-h-full object-contain group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                  {product.category === 'PDF Content' ? (
                    <span className="bg-red-600 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">
                      PDF - Página {product.pageNumber}
                    </span>
                  ) : (
                    <span className="bg-navy text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">
                      {product.category || 'Produto'}
                    </span>
                  )}
                </div>
              </div>
              <div className="p-8 flex-1 flex flex-col">
                <div className="flex items-start justify-between gap-4 mb-4">
                  <h3 className="text-xl font-bold text-navy leading-tight line-clamp-2">{product.name}</h3>
                  {product.code && (
                    <span className="text-[10px] font-black font-mono bg-gray-100 text-gray-500 px-3 py-1 rounded-lg">
                      {product.code}
                    </span>
                  )}
                </div>
                
                {product.brand && (
                  <p className="text-xs font-black text-blue-600 uppercase tracking-[0.2em] mb-4">
                    {product.brand}
                  </p>
                )}

                <p className="text-sm text-gray-500 line-clamp-3 mb-8 flex-1 leading-relaxed">
                  {product.description || 'Sem descrição disponível.'}
                </p>
                
                <div className="flex items-center justify-between mt-auto pt-6 border-t border-gray-50">
                  <div className="flex flex-col">
                    <span className="text-xs text-gray-400 uppercase font-bold tracking-widest">Preço</span>
                    <span className="text-2xl font-black text-navy">{formatCurrency(product.price)}</span>
                  </div>
                  <button
                    onClick={() => addToCart(product)}
                    className="p-4 bg-gray-100 text-navy rounded-2xl hover:bg-navy hover:text-white transition-all duration-300 shadow-sm"
                    title="Adicionar ao Orçamento"
                  >
                    <ShoppingCart className="w-6 h-6" />
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full py-32 text-center">
            <div className="bg-gray-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
              <Package className="w-12 h-12 text-gray-300" />
            </div>
            <h3 className="text-2xl font-bold text-navy">Nenhum resultado encontrado</h3>
            <p className="text-gray-500 max-w-sm mx-auto mt-2">Tente buscar por outro termo ou selecione um catálogo específico.</p>
          </div>
        )}
      </div>
    </div>
  );
}
