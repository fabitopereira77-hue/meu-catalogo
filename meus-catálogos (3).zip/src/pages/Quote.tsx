import React, { useState, useEffect } from 'react';
import { collection, addDoc, query, where, getDocs, orderBy, startAt, endAt, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { Quote, QuoteItem, Product } from '../types';
import { toast } from 'sonner';
import { Trash2, Send, Plus, Minus, FileText, User, Mail, Calculator, Search as SearchIcon, ShoppingCart, Share2, MessageCircle } from 'lucide-react';
import { formatCurrency } from '../lib/utils';

export default function QuotePage() {
  const { user, profile } = useAuth();
  const [items, setItems] = useState<QuoteItem[]>([]);
  const [clientEmail, setClientEmail] = useState('');
  const [clientName, setClientName] = useState('');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<Quote[]>([]);
  
  // Search state
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    const savedCart = localStorage.getItem('quote_cart');
    if (savedCart) {
      setItems(JSON.parse(savedCart));
    }
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    if (!user) return;
    try {
      const q = query(
        collection(db, 'quotes'),
        where('repId', '==', user.uid),
        orderBy('createdAt', 'desc')
      );
      const querySnapshot = await getDocs(q);
      setHistory(querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Quote)));
    } catch (error) {
      console.error(error);
    }
  };

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchTerm.trim()) {
      setSearchResults([]);
      return;
    }
    
    setSearching(true);
    try {
      // We'll fetch a larger set and filter client-side for better UX 
      // since Firestore doesn't support full-text search across multiple fields well
      const q = query(collection(db, 'products'), limit(100));
      const querySnapshot = await getDocs(q);
      const allProducts = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
      
      const term = searchTerm.toLowerCase().trim();
      const filtered = allProducts.filter(p => 
        p.name.toLowerCase().includes(term) || 
        p.brand?.toLowerCase().includes(term) ||
        p.code?.toLowerCase().includes(term) ||
        p.description?.toLowerCase().includes(term)
      );
      
      setSearchResults(filtered);
      if (filtered.length === 0) toast.info('Nenhum produto encontrado.');
    } catch (error) {
      console.error(error);
      toast.error('Erro ao buscar produtos.');
    } finally {
      setSearching(false);
    }
  };

  // Auto-search as user types (debounced)
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchTerm.length >= 2) {
        handleSearch();
      } else if (searchTerm.length === 0) {
        setSearchResults([]);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const addToCart = (product: Product) => {
    const existing = items.find(item => item.productId === product.id);
    let newItems;
    if (existing) {
      newItems = items.map(item => 
        item.productId === product.id ? { ...item, quantity: item.quantity + 1 } : item
      );
    } else {
      newItems = [...items, {
        productId: product.id,
        name: product.name,
        price: product.price,
        brand: product.brand,
        code: product.code,
        quantity: 1
      }];
    }
    setItems(newItems);
    localStorage.setItem('quote_cart', JSON.stringify(newItems));
    toast.success(`${product.name} adicionado!`);
  };

  const updateQuantity = (productId: string, delta: number) => {
    const newItems = items.map(item => {
      if (item.productId === productId) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    });
    setItems(newItems);
    localStorage.setItem('quote_cart', JSON.stringify(newItems));
  };

  const removeItem = (productId: string) => {
    const newItems = items.filter(item => item.productId !== productId);
    setItems(newItems);
    localStorage.setItem('quote_cart', JSON.stringify(newItems));
    toast.info('Produto removido.');
  };

  const total = items.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  const handleCreateQuote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || items.length === 0) return;

    setLoading(true);
    try {
      const quoteData = {
        repId: user.uid,
        repName: profile?.name,
        clientEmail,
        clientName,
        items,
        total,
        status: 'sent',
        createdAt: new Date().toISOString()
      };

      const docRef = await addDoc(collection(db, 'quotes'), quoteData);
      const quoteId = docRef.id;
      const quoteUrl = `${window.location.origin}/client/quote/${quoteId}`;

      toast.success('Orçamento criado com sucesso!');
      
      // Auto-share options
      const shareText = `Olá ${clientName}, segue seu orçamento no valor de ${formatCurrency(total)}. Confira os detalhes no link abaixo:`;
      
      // Clear cart
      setItems([]);
      localStorage.removeItem('quote_cart');
      setClientEmail('');
      setClientName('');
      fetchHistory();
      
      // Open share options immediately
      handleShare(quoteUrl, shareText);
    } catch (error) {
      console.error(error);
      toast.error('Erro ao criar orçamento.');
    } finally {
      setLoading(false);
    }
  };

  const handleShare = async (url: string, text: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Orçamento - Meus Catálogos',
          text: text,
          url: url,
        });
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          console.error(err);
        }
      }
    } else {
      // Fallback: Copy to clipboard and open WhatsApp
      try {
        await navigator.clipboard.writeText(`${text}\n\nLink: ${url}`);
        toast.success('Link copiado para a área de transferência!');
        window.open(`https://wa.me/?text=${encodeURIComponent(text + '\n\n' + url)}`, '_blank');
      } catch (err) {
        window.open(`https://wa.me/?text=${encodeURIComponent(text + '\n\n' + url)}`, '_blank');
      }
    }
  };

  const shareViaWhatsApp = (quote: Quote) => {
    const url = `${window.location.origin}/client/quote/${quote.id}`;
    const text = `Olá ${quote.clientName || ''}, segue seu orçamento no valor de ${formatCurrency(quote.total)}. Confira os detalhes no link abaixo:`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text + '\n\n' + url)}`, '_blank');
  };

  const shareViaEmail = (quote: Quote) => {
    const url = `${window.location.origin}/client/quote/${quote.id}`;
    const subject = `Orçamento para ${quote.clientName || 'Cliente'} - Meus Catálogos`;
    const body = `Olá ${quote.clientName || ''},\n\nSegue o link para visualizar seu orçamento no valor de ${formatCurrency(quote.total)}:\n\n${url}\n\nAtenciosamente,\n${profile?.name || 'Representante'}`;
    window.open(`mailto:${quote.clientEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, '_blank');
  };

  return (
    <div className="container mx-auto px-4 py-12 space-y-8">
      {/* Search Section */}
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
          <SearchIcon className="w-6 h-6 text-blue-600" />
          Buscar Produtos para Orçamento
        </h2>
        <form onSubmit={handleSearch} className="flex gap-4">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Nome, marca ou código do produto..."
            className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
          />
          <button
            type="submit"
            disabled={searching}
            className="bg-blue-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-700 transition-all disabled:opacity-50"
          >
            {searching ? 'Buscando...' : 'Buscar'}
          </button>
        </form>

        {searchResults.length > 0 && (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-96 overflow-y-auto p-2">
            {searchResults.map((product) => (
              <div key={product.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-2xl border border-gray-100 hover:border-blue-200 transition-all">
                <img
                  src={product.imageUrl || `https://picsum.photos/seed/${product.name}/100/100`}
                  alt={product.name}
                  className="w-16 h-16 rounded-xl object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-gray-900 truncate">{product.name}</h4>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    {product.brand && <span className="font-semibold text-blue-600">{product.brand}</span>}
                    {product.code && <span className="font-mono">#{product.code}</span>}
                  </div>
                  <p className="text-sm font-black text-gray-900 mt-1">{formatCurrency(product.price)}</p>
                </div>
                <button
                  onClick={() => addToCart(product)}
                  className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-8">
              <h1 className="text-3xl font-bold text-gray-900">Itens Selecionados</h1>
              <div className="bg-blue-50 px-4 py-2 rounded-xl flex items-center gap-2 text-blue-700 font-bold">
                <Calculator className="w-5 h-5" />
                <span>{items.length} Itens</span>
              </div>
            </div>

            {items.length > 0 ? (
              <div className="space-y-4">
                {items.map((item) => (
                  <div key={item.productId} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl border border-gray-100">
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-900">{item.name}</h3>
                      <div className="flex items-center gap-2 text-xs text-gray-500 mb-1">
                        {item.brand && <span className="font-semibold text-blue-600">{item.brand}</span>}
                        {item.code && <span className="font-mono">#{item.code}</span>}
                      </div>
                      <p className="text-sm text-gray-500">{formatCurrency(item.price)} / un</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center bg-white rounded-xl border border-gray-200 p-1">
                        <button
                          onClick={() => updateQuantity(item.productId, -1)}
                          className="p-1 hover:bg-gray-100 rounded-lg text-gray-500"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="w-10 text-center font-bold">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.productId, 1)}
                          className="p-1 hover:bg-gray-100 rounded-lg text-gray-500"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="w-24 text-right font-bold text-gray-900">
                        {formatCurrency(item.price * item.quantity)}
                      </div>
                      <button
                        onClick={() => removeItem(item.productId)}
                        className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
                
                <div className="mt-8 pt-8 border-t border-gray-100 flex justify-between items-center">
                  <span className="text-xl font-medium text-gray-500">Total do Orçamento</span>
                  <span className="text-4xl font-black text-blue-600">{formatCurrency(total)}</span>
                </div>
              </div>
            ) : (
              <div className="py-20 text-center">
                <div className="bg-gray-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FileText className="w-10 h-10 text-gray-300" />
                </div>
                <p className="text-gray-500">Busque e adicione produtos para começar o orçamento.</p>
              </div>
            )}
          </div>

          <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Histórico de Orçamentos</h2>
            <div className="space-y-4">
              {history.map((quote) => (
                <div key={quote.id} className="p-4 border border-gray-100 rounded-2xl hover:bg-gray-50 transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-bold text-gray-900">{quote.clientName || quote.clientEmail}</h4>
                      <p className="text-xs text-gray-400">{new Date(quote.createdAt).toLocaleString('pt-BR')}</p>
                    </div>
                    <span className="text-lg font-bold text-blue-600">{formatCurrency(quote.total)}</span>
                  </div>
                  <div className="flex items-center justify-between mt-4">
                    <span className={`text-xs px-2 py-1 rounded-md font-bold uppercase tracking-wider ${
                      quote.status === 'accepted' ? 'bg-green-50 text-green-600' : 
                      quote.status === 'rejected' ? 'bg-red-50 text-red-600' : 
                      'bg-blue-50 text-blue-600'
                    }`}>
                      {quote.status}
                    </span>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => shareViaWhatsApp(quote)}
                        className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                        title="Compartilhar via WhatsApp"
                      >
                        <MessageCircle className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => shareViaEmail(quote)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Enviar por E-mail"
                      >
                        <Mail className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => handleShare(`${window.location.origin}/client/quote/${quote.id}`, `Olá, segue seu orçamento: ${window.location.origin}/client/quote/${quote.id}`)}
                        className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                        title="Compartilhar Link"
                      >
                        <Share2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-navy p-8 rounded-3xl shadow-sm border border-gray-100 sticky top-8 text-white">
            <h2 className="text-xl font-bold mb-6">Dados do Cliente</h2>
            <form onSubmit={handleCreateQuote} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-blue-100 flex items-center gap-2">
                  <User className="w-4 h-4" /> Nome do Cliente
                </label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  required
                  className="w-full px-4 py-3 rounded-xl border-none bg-white/10 text-white placeholder:text-blue-200 focus:ring-2 focus:ring-blue-400 outline-none"
                  placeholder="Ex: João Silva"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-blue-100 flex items-center gap-2">
                  <Mail className="w-4 h-4" /> E-mail do Cliente
                </label>
                <input
                  type="email"
                  value={clientEmail}
                  onChange={(e) => setClientEmail(e.target.value)}
                  required
                  className="w-full px-4 py-3 rounded-xl border-none bg-white/10 text-white placeholder:text-blue-200 focus:ring-2 focus:ring-blue-400 outline-none"
                  placeholder="cliente@email.com"
                />
              </div>
              <button
                type="submit"
                disabled={loading || items.length === 0}
                className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-900/20 disabled:opacity-50 flex items-center justify-center gap-2 mt-4"
              >
                {loading ? 'Processando...' : 'Finalizar e Enviar'}
                {!loading && <Send className="w-5 h-5" />}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
