import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, addDoc, writeBatch, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { Catalog, Product } from '../types';
import { toast } from 'sonner';
import { Plus, Upload, FileText, Table, ExternalLink, Search as SearchIcon, Image as ImageIcon, Copy, X, BookOpen, Globe, Edit2, Trash2 } from 'lucide-react';
import { parseExcel, parsePDF } from '../services/fileParser';
import { Link, useNavigate } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'all' | 'mine'>('all');
  const [catalogs, setCatalogs] = useState<Catalog[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [showUpload, setShowUpload] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [importStatus, setImportStatus] = useState('');
  const [selectedCatalog, setSelectedCatalog] = useState<Catalog | null>(null);
  const [editingCatalog, setEditingCatalog] = useState<Catalog | null>(null);
  const [deletingCatalogId, setDeletingCatalogId] = useState<string | null>(null);
  const [newCoverUrl, setNewCoverUrl] = useState('');

  useEffect(() => {
    fetchCatalogs();
  }, []);

  const fetchCatalogs = async () => {
    try {
      const q = query(collection(db, 'catalogs'));
      const querySnapshot = await getDocs(q);
      const fetchedCatalogs = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Catalog));
      setCatalogs(fetchedCatalogs);
    } catch (error) {
      console.error(error);
      toast.error('Erro ao carregar catálogos.');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;

    const formData = new FormData(e.currentTarget);
    const externalLogoUrl = formData.get('externalLogoUrl') as string;
    const externalCoverUrl = formData.get('externalCoverUrl') as string;
    const name = formData.get('name') as string;
    const externalUrl = formData.get('externalUrl') as string;

    if (!name || !externalUrl) {
      toast.error('Preencha o nome da representada e a URL do catálogo.');
      return;
    }

    setUploading(true);
    setUploadProgress(0);
    setImportStatus('Iniciando...');
    try {
      let fileUrl = externalUrl;
      let type: 'pdf' | 'excel' | 'image' | 'external' = 'external';

      if (externalUrl.match(/\.(jpg|jpeg|png|webp|gif)(\?.*)?$/i)) {
        type = 'image';
      } else if (externalUrl.toLowerCase().includes('.pdf')) {
        type = 'pdf';
      } else {
        type = 'external';
      }

      let logoUrl = externalLogoUrl || '';
      let coverUrl = externalCoverUrl || '';
      
      if (!coverUrl) {
        if (type === 'image') {
          coverUrl = fileUrl;
        } else {
          coverUrl = `https://picsum.photos/seed/${name}/400/600`;
        }
      }

      setUploadProgress(20);
      setImportStatus('Processando catálogo...');

      let productsToIndex: any[] = [];

      // Try to index PDF if it's a PDF link
      if (type === 'pdf') {
        try {
          setImportStatus('Baixando PDF para indexação...');
          const response = await fetch(fileUrl);
          if (response.ok) {
            const blob = await response.blob();
            const file = new File([blob], `${name}.pdf`, { type: 'application/pdf' });
            
            setImportStatus('Lendo conteúdo do PDF...');
            const textContent = await parsePDF(file);
            
            productsToIndex = textContent.map((text, i) => ({
              name: `Página ${i + 1} - ${name}`,
              description: text.substring(0, 1500), // Index more text
              price: 0,
              brand: name,
              code: `P${i + 1}`,
              category: 'PDF Content',
              pageNumber: i + 1
            }));
          }
        } catch (fetchErr) {
          console.warn('Não foi possível indexar o PDF devido a restrições de CORS ou rede:', fetchErr);
          // We continue anyway, just won't have search results for this PDF content
        }
      }

      setUploadProgress(60);
      setImportStatus('Salvando catálogo...');
      
      const catalogData = {
        repId: user.uid,
        name,
        type,
        fileUrl,
        logoUrl,
        createdAt: new Date().toISOString(),
        coverUrl
      };
      
      const catalogRef = await addDoc(collection(db, 'catalogs'), catalogData);

      if (productsToIndex.length > 0) {
        setImportStatus(`Indexando ${productsToIndex.length} páginas...`);
        const batchSize = 20;
        for (let i = 0; i < productsToIndex.length; i += batchSize) {
          const batch = productsToIndex.slice(i, i + batchSize);
          await Promise.all(batch.map(product => 
            addDoc(collection(db, 'products'), {
              ...product,
              catalogId: catalogRef.id,
              repId: user.uid,
              createdAt: new Date().toISOString()
            })
          ));
          setUploadProgress(60 + (40 * (i + batch.length) / productsToIndex.length));
        }
      }

      setUploadProgress(100);
      toast.success('Catálogo publicado e indexado com sucesso!');
      setShowUpload(false);
      fetchCatalogs();
    } catch (error) {
      console.error(error);
      toast.error(`Erro ao publicar catálogo: ${(error as Error).message}`);
    } finally {
      setUploading(false);
    }
  };

  const copyToClipboard = (url: string) => {
    navigator.clipboard.writeText(url);
    toast.success('Link do catálogo copiado!');
  };

  const handleDeleteCatalog = async (catalogId: string) => {
    try {
      // 1. Delete products associated with this catalog in chunks to avoid batch limits
      const productsQuery = query(collection(db, 'products'), where('catalogId', '==', catalogId));
      const productsSnapshot = await getDocs(productsQuery);
      
      if (!productsSnapshot.empty) {
        const docs = productsSnapshot.docs;
        for (let i = 0; i < docs.length; i += 400) {
          const batch = writeBatch(db);
          docs.slice(i, i + 400).forEach((doc) => {
            batch.delete(doc.ref);
          });
          await batch.commit();
        }
      }

      // 2. Delete the catalog itself
      await deleteDoc(doc(db, 'catalogs', catalogId));
      
      toast.success('Catálogo excluído com sucesso!');
      fetchCatalogs();
    } catch (error) {
      console.error('Erro ao excluir catálogo:', error);
      toast.error('Erro ao excluir catálogo. Verifique sua conexão.');
    }
  };

  const handleUpdateCatalog = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editingCatalog) return;

    const formData = new FormData(e.currentTarget);
    const name = formData.get('name') as string;
    const externalLogoUrl = formData.get('externalLogoUrl') as string;
    const externalUrl = formData.get('externalUrl') as string;
    const externalCoverUrl = formData.get('externalCoverUrl') as string;

    try {
      await updateDoc(doc(db, 'catalogs', editingCatalog.id), {
        name,
        logoUrl: externalLogoUrl,
        fileUrl: externalUrl,
        coverUrl: externalCoverUrl
      });

      toast.success('Catálogo atualizado com sucesso!');
      setEditingCatalog(null);
      fetchCatalogs();
    } catch (error) {
      console.error(error);
      toast.error('Erro ao atualizar catálogo.');
    }
  };

  const filteredCatalogs = activeTab === 'all' 
    ? catalogs 
    : catalogs.filter(c => c.repId === user?.uid);

  return (
    <div className="space-y-16 pb-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-navy text-white overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-navy via-[#002b5c] to-graphite opacity-90"></div>
        <div className="relative container mx-auto px-8 text-center space-y-10">
          <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-none">
            Soluções em <br />
            <span className="text-blue-400">Representação</span>
          </h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto font-light leading-relaxed">
            Busque produtos em todos os nossos catálogos de forma inteligente e rápida. 
            A tecnologia a serviço do seu negócio.
          </p>
          
          <div className="max-w-4xl mx-auto relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-navy rounded-[2rem] blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                const q = new FormData(e.currentTarget).get('q');
                if (q) navigate(`/search?q=${q}`);
              }}
              className="relative flex flex-col md:flex-row items-center bg-white rounded-[2rem] shadow-2xl overflow-hidden p-3"
            >
              <div className="flex-1 flex items-center w-full px-6">
                <SearchIcon className="w-8 h-8 text-gray-400" />
                <input
                  name="q"
                  type="text"
                  placeholder="O que você está procurando? (ex: Parafuso sextavado)"
                  className="w-full px-6 py-8 text-2xl text-gray-900 outline-none placeholder:text-gray-400 font-medium"
                />
              </div>
              <button 
                type="submit"
                className="w-full md:w-auto bg-navy text-white px-16 py-8 rounded-[1.5rem] text-xl font-black hover:bg-blue-900 transition-all shadow-xl uppercase tracking-widest"
              >
                Buscar
              </button>
            </form>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 space-y-24">
        {/* Catalog Gallery Section */}
        <section id="catalogos" className="space-y-12">
        <div className="flex items-center justify-between border-b border-gray-100 pb-6">
          <div>
            <h2 className="text-3xl font-bold text-navy">Galeria de Catálogos</h2>
            <p className="text-gray-500 mt-1">Marcas e fábricas que representamos</p>
          </div>
          
          {profile?.role === 'rep' && (
            <div className="flex items-center gap-4">
              <div className="flex p-1 bg-gray-100 rounded-xl">
                <button
                  onClick={() => setActiveTab('all')}
                  className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'all' ? 'bg-white text-navy shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  Todos
                </button>
                <button
                  onClick={() => setActiveTab('mine')}
                  className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'mine' ? 'bg-white text-navy shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  Meus Catálogos
                </button>
              </div>
              <button
                onClick={() => setShowUpload(!showUpload)}
                className="flex items-center gap-2 bg-navy text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-900 transition-all shadow-lg"
              >
                <Plus className="w-5 h-5" />
                <span>Novo Catálogo</span>
              </button>
            </div>
          )}
        </div>

        {showUpload && (
          <div className="bg-white p-8 rounded-3xl shadow-xl border border-gray-100 animate-in fade-in slide-in-from-top-4 duration-300">
            <h2 className="text-2xl font-bold text-navy mb-6">Publicar Novo Catálogo</h2>
            <form onSubmit={handleFileUpload} className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">Nome da Representada</label>
                <input
                  name="name"
                  required
                  className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-navy focus:border-transparent outline-none transition-all"
                  placeholder="Ex: Indústria Têxtil ABC"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">URL do Logotipo</label>
                <input
                  name="externalLogoUrl"
                  required
                  className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-navy focus:border-transparent outline-none transition-all"
                  placeholder="https://exemplo.com/logo.png"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">URL da Capa (Opcional)</label>
                <input
                  name="externalCoverUrl"
                  className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-navy focus:border-transparent outline-none transition-all"
                  placeholder="https://exemplo.com/capa.jpg"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">URL do Catálogo (PDF ou Link)</label>
                <input
                  name="externalUrl"
                  required
                  type="url"
                  className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-navy focus:border-transparent outline-none transition-all"
                  placeholder="https://exemplo.com/catalogo.pdf"
                />
              </div>

              <div className="md:col-span-2 flex flex-col gap-4">
                {uploading && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm font-medium text-gray-600">
                      <span>{importStatus}</span>
                      <span>{Math.round(uploadProgress)}%</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                      <div 
                        className="bg-navy h-full transition-all duration-300" 
                        style={{ width: `${uploadProgress}%` }}
                      ></div>
                    </div>
                  </div>
                )}
                <div className="flex justify-end gap-4">
                  <button
                    type="button"
                    onClick={() => setShowUpload(false)}
                    className="px-8 py-4 rounded-xl font-bold text-gray-600 hover:bg-gray-100 transition-all"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={uploading}
                    className="flex items-center gap-2 bg-navy text-white px-10 py-4 rounded-xl font-bold hover:bg-blue-900 transition-all disabled:opacity-50 shadow-lg"
                  >
                    {uploading ? 'Processando...' : 'Salvar Catálogo'}
                    {!uploading && <Upload className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            </form>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
          {loading ? (
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="bg-gray-100 animate-pulse rounded-[2rem] aspect-[3/4.5]"></div>
            ))
          ) : filteredCatalogs.length > 0 ? (
            filteredCatalogs.map((catalog) => (
              <div key={catalog.id} className="group flex flex-col bg-white rounded-[2rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 border border-gray-100">
                <div className="relative aspect-[3/4] overflow-hidden bg-gray-50">
                  <img
                    src={catalog.coverUrl}
                    alt={catalog.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  
                  {profile?.role === 'rep' && profile.uid === catalog.repId && activeTab === 'mine' && (
                    <div className="absolute top-6 left-6 flex flex-col gap-3 z-10">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingCatalog(catalog);
                        }}
                        className="w-12 h-12 bg-white shadow-xl rounded-2xl flex items-center justify-center text-gray-600 hover:text-navy transition-colors"
                        title="Editar Catálogo"
                      >
                        <Edit2 className="w-6 h-6" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeletingCatalogId(catalog.id);
                        }}
                        className="w-12 h-12 bg-white shadow-xl rounded-2xl flex items-center justify-center text-gray-600 hover:text-red-600 transition-colors"
                        title="Excluir Catálogo"
                      >
                        <Trash2 className="w-6 h-6" />
                      </button>
                    </div>
                  )}
                </div>
                <div className="p-8 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      {catalog.logoUrl && (
                        <a href={catalog.fileUrl} target="_blank" rel="noopener noreferrer" className="hover:scale-110 transition-transform">
                          <img src={catalog.logoUrl} alt="Logo" className="w-10 h-10 object-contain rounded-lg" referrerPolicy="no-referrer" />
                        </a>
                      )}
                      <span className="text-[10px] uppercase font-black tracking-[0.2em] text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
                        {catalog.type}
                      </span>
                    </div>
                    <h3 className="text-2xl font-bold text-navy leading-tight">{catalog.name}</h3>
                  </div>
                  <div className="mt-8 pt-6 border-t border-gray-50 flex items-center justify-between">
                    <Link 
                      to={`/search?catalogId=${catalog.id}`} 
                      className="text-sm font-bold text-navy hover:text-blue-600 flex items-center gap-2 transition-colors"
                    >
                      <SearchIcon className="w-5 h-5" />
                      Buscar Produtos
                    </Link>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full py-32 text-center">
              <div className="bg-gray-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
                <BookOpen className="w-12 h-12 text-gray-300" />
              </div>
              <h3 className="text-2xl font-bold text-navy">Nenhum catálogo disponível</h3>
              <p className="text-gray-500 max-w-sm mx-auto mt-2">Explore nossas representações ou entre em contato para mais informações.</p>
            </div>
          )}
        </div>
      </section>

      {/* Quick Quote Section */}
      <section id="cotacao" className="bg-graphite text-white rounded-[2rem] p-12 md:p-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <h2 className="text-4xl md:text-5xl font-bold leading-tight">
              Sistema de <br />
              <span className="text-blue-400">Cotação Rápida</span>
            </h2>
            <p className="text-xl text-gray-400 font-light leading-relaxed">
              Encontrou o que precisava? Solicite um orçamento agora mesmo. 
              Nossa equipe responderá o mais breve possível com as melhores condições.
            </p>
            <div className="flex items-center gap-6">
              <div className="flex -space-x-4">
                {[1,2,3].map(i => (
                  <img key={i} src={`https://picsum.photos/seed/${i+10}/100/100`} className="w-12 h-12 rounded-full border-4 border-graphite" />
                ))}
              </div>
              <p className="text-sm text-gray-400">+500 orçamentos atendidos este mês</p>
            </div>
          </div>
          
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              toast.success('Solicitação de cotação enviada com sucesso!');
              (e.target as HTMLFormElement).reset();
            }}
            className="bg-white rounded-3xl p-8 md:p-10 space-y-6 shadow-2xl"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest">Produto ou Código</label>
                <input required className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none text-gray-900 focus:ring-2 focus:ring-navy outline-none" placeholder="Ex: Parafuso X-123" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest">Quantidade</label>
                <input required type="number" className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none text-gray-900 focus:ring-2 focus:ring-navy outline-none" placeholder="Ex: 500" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-widest">Seu Nome</label>
              <input required className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none text-gray-900 focus:ring-2 focus:ring-navy outline-none" placeholder="João Silva" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest">Empresa</label>
                <input required className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none text-gray-900 focus:ring-2 focus:ring-navy outline-none" placeholder="Minha Empresa Ltda" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest">WhatsApp</label>
                <input required className="w-full px-5 py-4 rounded-xl bg-gray-50 border-none text-gray-900 focus:ring-2 focus:ring-navy outline-none" placeholder="(00) 00000-0000" />
              </div>
            </div>
            <button type="submit" className="w-full bg-navy text-white py-5 rounded-2xl font-bold text-lg hover:bg-blue-900 transition-all shadow-xl shadow-navy/20">
              Solicitar Orçamento
            </button>
          </form>
        </div>
      </section>
    </div>

      {/* Edit Catalog Modal */}
      {editingCatalog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl animate-in zoom-in duration-300">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-900">Editar Catálogo</h3>
              <button onClick={() => setEditingCatalog(null)} className="text-gray-400 hover:text-gray-600">
                <X className="w-6 h-6" />
              </button>
            </div>
            <form onSubmit={handleUpdateCatalog} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Nome da Representada</label>
                <input
                  name="name"
                  required
                  defaultValue={editingCatalog.name}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">URL do Logotipo</label>
                <input
                  name="externalLogoUrl"
                  required
                  defaultValue={editingCatalog.logoUrl}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  placeholder="https://exemplo.com/logo.png"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">URL do Catálogo (PDF/Site)</label>
                <input
                  name="externalUrl"
                  required
                  defaultValue={editingCatalog.fileUrl}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  placeholder="https://exemplo.com/catalogo.pdf"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">URL da Capa</label>
                <input
                  name="externalCoverUrl"
                  required
                  defaultValue={editingCatalog.coverUrl}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  placeholder="https://exemplo.com/capa.jpg"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setEditingCatalog(null)}
                  className="flex-1 px-6 py-3 rounded-xl font-semibold text-gray-600 hover:bg-gray-100 transition-all"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
                >
                  Salvar Alterações
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deletingCatalogId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[70]">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl animate-in zoom-in duration-300">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Excluir Catálogo</h3>
            <p className="text-gray-500 mb-8">
              Tem certeza que deseja excluir este catálogo? Esta ação não pode ser desfeita e todos os produtos associados serão removidos.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeletingCatalogId(null)}
                className="flex-1 px-6 py-3 rounded-xl font-semibold text-gray-600 hover:bg-gray-100 transition-all"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  handleDeleteCatalog(deletingCatalogId);
                  setDeletingCatalogId(null);
                }}
                className="flex-1 bg-red-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-red-700 transition-all shadow-lg shadow-red-100"
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Viewer Modal */}
      {selectedCatalog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-6xl h-[90vh] rounded-3xl overflow-hidden flex flex-col shadow-2xl">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">{selectedCatalog.name}</h3>
                  <p className="text-xs text-gray-500 capitalize">{selectedCatalog.type}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <a 
                  href={selectedCatalog.fileUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                  title="Abrir em nova aba"
                >
                  <ExternalLink className="w-5 h-5" />
                </a>
                <button 
                  onClick={() => setSelectedCatalog(null)}
                  className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            <div className="flex-1 bg-gray-50 overflow-auto">
              {selectedCatalog.type === 'image' ? (
                <div className="w-full h-full flex items-center justify-center p-8">
                  <img 
                    src={selectedCatalog.fileUrl} 
                    alt={selectedCatalog.name} 
                    className="max-w-full max-h-full object-contain rounded-lg shadow-lg"
                    referrerPolicy="no-referrer"
                  />
                </div>
              ) : selectedCatalog.type === 'pdf' || selectedCatalog.type === 'external' ? (
                <iframe 
                  src={selectedCatalog.fileUrl} 
                  className="w-full h-full border-none"
                  title={selectedCatalog.name}
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center">
                  <Table className="w-16 h-16 text-green-600 mb-4" />
                  <h4 className="text-xl font-bold text-gray-900">Visualização de Planilha</h4>
                  <p className="text-gray-500 mt-2 max-w-md">
                    Planilhas Excel não podem ser visualizadas diretamente no navegador. 
                    Por favor, utilize a busca de produtos ou faça o download do arquivo.
                  </p>
                  <a 
                    href={selectedCatalog.fileUrl}
                    className="mt-6 bg-green-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-green-700 transition-all"
                  >
                    Baixar Planilha
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
