import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { Quote } from '../types';
import { toast } from 'sonner';
import { FileCheck, FileX, Download, Printer, User, Mail, Calendar, ShoppingCart } from 'lucide-react';
import { formatCurrency } from '../lib/utils';

export default function ClientQuote() {
  const { quoteId } = useParams<{ quoteId: string }>();
  const [quote, setQuote] = useState<Quote | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchQuote();
  }, [quoteId]);

  const fetchQuote = async () => {
    if (!quoteId) return;
    try {
      const docSnap = await getDoc(doc(db, 'quotes', quoteId));
      if (docSnap.exists()) {
        setQuote({ id: docSnap.id, ...docSnap.data() } as Quote);
      } else {
        toast.error('Orçamento não encontrado.');
      }
    } catch (error) {
      console.error(error);
      toast.error('Erro ao carregar orçamento.');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (status: 'accepted' | 'rejected') => {
    if (!quoteId) return;
    try {
      await updateDoc(doc(db, 'quotes', quoteId), { status });
      setQuote(prev => prev ? { ...prev, status } : null);
      toast.success(`Orçamento ${status === 'accepted' ? 'aceito' : 'rejeitado'} com sucesso!`);
    } catch (error) {
      console.error(error);
      toast.error('Erro ao atualizar status.');
    }
  };

  if (loading) return <div className="flex items-center justify-center h-screen text-gray-500">Carregando orçamento...</div>;
  if (!quote) return <div className="text-center py-20 text-gray-500">Orçamento não encontrado.</div>;

  return (
    <div className="container mx-auto px-4 py-12 space-y-8">
      <div className="max-w-4xl mx-auto bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-gray-100">
        <div className="flex flex-col md:flex-row justify-between items-start gap-8 mb-12">
          <div>
            <div className="flex items-center gap-2 text-blue-600 font-bold mb-2">
              <ShoppingCart className="w-6 h-6" />
              <span className="text-xl">Meus Catálogos</span>
            </div>
            <h1 className="text-4xl font-black text-gray-900 tracking-tight">Orçamento #{quote.id.substring(0, 8)}</h1>
            <div className="flex items-center gap-4 mt-4">
              <span className={`px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest ${
                quote.status === 'accepted' ? 'bg-green-100 text-green-700' : 
                quote.status === 'rejected' ? 'bg-red-100 text-red-700' : 
                'bg-blue-100 text-blue-700'
              }`}>
                {quote.status}
              </span>
              <span className="text-sm text-gray-400 flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {new Date(quote.createdAt).toLocaleDateString('pt-BR')}
              </span>
            </div>
          </div>
          
          <div className="flex gap-3">
            <button onClick={() => window.print()} className="p-3 bg-gray-50 text-gray-600 rounded-xl hover:bg-gray-100 transition-all">
              <Printer className="w-5 h-5" />
            </button>
            <button className="p-3 bg-gray-50 text-gray-600 rounded-xl hover:bg-gray-100 transition-all">
              <Download className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12 p-8 bg-gray-50 rounded-2xl border border-gray-100">
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Representante</h3>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                <User className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-gray-900">{(quote as any).repName || 'Representante'}</p>
                <p className="text-sm text-gray-500">Vendedor Autorizado</p>
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Cliente</h3>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-gray-500">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-gray-900">{(quote as any).clientName || 'Cliente'}</p>
                <p className="text-sm text-gray-500">{quote.clientEmail}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4 mb-12">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Itens do Pedido</h3>
          <div className="overflow-hidden border border-gray-100 rounded-2xl">
            <table className="w-full text-left border-collapse">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Produto</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest text-center">Qtd</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest text-right">Preço</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {quote.items.map((item, i) => (
                  <tr key={i} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <p className="font-bold text-gray-900">{item.name}</p>
                      <div className="flex items-center gap-2 text-[10px] text-gray-400">
                        {item.brand && <span className="font-semibold text-blue-600">{item.brand}</span>}
                        {item.code && <span className="font-mono">#{item.code}</span>}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center font-medium text-gray-600">{item.quantity}</td>
                    <td className="px-6 py-4 text-right text-gray-500">{formatCurrency(item.price)}</td>
                    <td className="px-6 py-4 text-right font-bold text-gray-900">{formatCurrency(item.price * item.quantity)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center gap-8 pt-8 border-t border-gray-100">
          <div className="text-center md:text-left">
            <p className="text-gray-500 font-medium">Valor Total do Orçamento</p>
            <p className="text-5xl font-black text-blue-600">{formatCurrency(quote.total)}</p>
          </div>
          
          {quote.status === 'sent' && (
            <div className="flex gap-4 w-full md:w-auto">
              <button
                onClick={() => handleStatusUpdate('rejected')}
                className="flex-1 md:flex-none flex items-center justify-center gap-2 px-8 py-4 rounded-2xl font-bold text-red-600 bg-red-50 hover:bg-red-100 transition-all"
              >
                <FileX className="w-5 h-5" />
                Recusar
              </button>
              <button
                onClick={() => handleStatusUpdate('accepted')}
                className="flex-1 md:flex-none flex items-center justify-center gap-2 px-12 py-4 rounded-2xl font-bold text-white bg-green-600 hover:bg-green-700 transition-all shadow-lg shadow-green-100"
              >
                <FileCheck className="w-5 h-5" />
                Aprovar Pedido
              </button>
            </div>
          )}
        </div>
      </div>
      
      <p className="text-center text-gray-400 text-sm">
        Este orçamento é válido por 7 dias a partir da data de emissão.
      </p>
    </div>
  );
}
