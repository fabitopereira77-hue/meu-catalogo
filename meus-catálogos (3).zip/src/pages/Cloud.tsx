import React, { useState, useEffect } from 'react';
import { ref, listAll, getDownloadURL, deleteObject, getMetadata, uploadBytesResumable } from 'firebase/storage';
import { collection, addDoc, query, where, getDocs, deleteDoc, doc } from 'firebase/firestore';
import { storage, db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { Cloud as CloudIcon, FileText, Table, Image as ImageIcon, Trash2, Download, Copy, ExternalLink, RefreshCw, Folder, Upload, X, BookOpen } from 'lucide-react';
import { toast } from 'sonner';

interface CloudFile {
  name: string;
  url: string;
  fullPath: string;
  size: number;
  contentType?: string;
  timeCreated: string;
}

export default function Cloud() {
  const { user } = useAuth();
  const [files, setFiles] = useState<CloudFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<CloudFile | null>(null);

  useEffect(() => {
    if (user) {
      fetchFiles();
    }
  }, [user]);

  const handleGeneralUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    if (file.size > 100 * 1024 * 1024) {
      toast.error('O arquivo é muito grande. O limite é de 100MB.');
      return;
    }

    setUploading(true);
    try {
      const fileRef = ref(storage, `catalogs/${user.uid}/${Date.now()}_${file.name}`);
      const uploadTask = await uploadBytesResumable(fileRef, file);
      const url = await getDownloadURL(uploadTask.ref);

      // Register in Firestore
      await addDoc(collection(db, 'external_links'), {
        userId: user.uid,
        name: file.name,
        url: url,
        type: file.type,
        fullPath: fileRef.fullPath,
        createdAt: new Date().toISOString()
      });

      toast.success('Arquivo enviado e registrado com sucesso!');
      fetchFiles();
    } catch (error) {
      console.error(error);
      toast.error('Erro ao enviar arquivo.');
    } finally {
      setUploading(false);
    }
  };

  const fetchFiles = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const catalogsRef = ref(storage, `catalogs/${user.uid}`);
      const logosRef = ref(storage, `logos/${user.uid}`);
      
      const [catalogsList, logosList] = await Promise.all([
        listAll(catalogsRef),
        listAll(logosRef)
      ]);

      const allItems = [...catalogsList.items, ...logosList.items];
      
      const filePromises = allItems.map(async (item) => {
        const [url, metadata] = await Promise.all([
          getDownloadURL(item),
          getMetadata(item)
        ]);
        return {
          name: item.name,
          url,
          fullPath: item.fullPath,
          size: metadata.size,
          contentType: metadata.contentType,
          timeCreated: metadata.timeCreated
        };
      });

      const fetchedFiles = await Promise.all(filePromises);
      // Sort by newest
      fetchedFiles.sort((a, b) => new Date(b.timeCreated).getTime() - new Date(a.timeCreated).getTime());
      setFiles(fetchedFiles);
    } catch (error) {
      console.error(error);
      toast.error('Erro ao carregar arquivos da nuvem.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (file: CloudFile) => {
    if (!window.confirm(`Tem certeza que deseja excluir o arquivo "${file.name}"?`)) return;
    
    try {
      // 1. Delete from Storage
      const fileRef = ref(storage, file.fullPath);
      await deleteObject(fileRef);

      // 2. Delete from Firestore (if exists)
      const q = query(collection(db, 'external_links'), where('url', '==', file.url));
      const querySnapshot = await getDocs(q);
      const deletePromises = querySnapshot.docs.map(d => deleteDoc(doc(db, 'external_links', d.id)));
      await Promise.all(deletePromises);

      setFiles(prev => prev.filter(f => f.fullPath !== file.fullPath));
      toast.success('Arquivo excluído com sucesso!');
    } catch (error) {
      console.error(error);
      toast.error('Erro ao excluir arquivo.');
    }
  };

  const copyToClipboard = (url: string) => {
    navigator.clipboard.writeText(url);
    toast.success('Link copiado para a área de transferência!');
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (contentType?: string) => {
    if (contentType?.includes('pdf')) return <FileText className="w-6 h-6 text-red-500" />;
    if (contentType?.includes('sheet') || contentType?.includes('excel')) return <Table className="w-6 h-6 text-green-500" />;
    if (contentType?.includes('image')) return <ImageIcon className="w-6 h-6 text-purple-500" />;
    return <FileText className="w-6 h-6 text-gray-500" />;
  };

  return (
    <div className="container mx-auto px-4 py-12 space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight flex items-center gap-3">
            <CloudIcon className="w-10 h-10 text-blue-600" />
            Minha Nuvem
          </h1>
          <p className="text-gray-500 mt-2">Gerencie seus arquivos armazenados no {user?.email}</p>
        </div>
        <div className="flex items-center gap-3">
          <label className={`flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 cursor-pointer ${uploading ? 'opacity-50 cursor-not-allowed' : ''}`}>
            <Upload className="w-5 h-5" />
            <span>{uploading ? 'Enviando...' : 'Enviar Arquivo'}</span>
            <input type="file" className="hidden" onChange={handleGeneralUpload} disabled={uploading} />
          </label>
          <button 
            onClick={fetchFiles}
            className="p-3 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-all shadow-sm"
            title="Atualizar"
          >
            <RefreshCw className={`w-5 h-5 text-gray-600 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50/50 border-b border-gray-100">
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-500">Arquivo</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-500">Tamanho</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-500">Data</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-500 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td className="px-6 py-4"><div className="h-4 bg-gray-100 rounded w-48"></div></td>
                    <td className="px-6 py-4"><div className="h-4 bg-gray-100 rounded w-16"></div></td>
                    <td className="px-6 py-4"><div className="h-4 bg-gray-100 rounded w-24"></div></td>
                    <td className="px-6 py-4"><div className="h-8 bg-gray-100 rounded w-24 ml-auto"></div></td>
                  </tr>
                ))
              ) : files.length > 0 ? (
                files.map((file) => (
                  <tr key={file.fullPath} className="hover:bg-gray-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-gray-50 rounded-lg group-hover:bg-white transition-colors">
                          {getFileIcon(file.contentType)}
                        </div>
                        <div>
                          <p className="font-bold text-gray-900 line-clamp-1">{file.name}</p>
                          <p className="text-xs text-gray-400">{file.contentType || 'Arquivo'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">{formatSize(file.size)}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      {new Date(file.timeCreated).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => copyToClipboard(file.url)}
                          className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                          title="Copiar Link da Nuvem"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setSelectedFile(file)}
                          className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-all"
                          title="Visualizar"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(file)}
                          className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                          title="Excluir"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-6 py-20 text-center">
                    <div className="bg-gray-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Folder className="w-8 h-8 text-gray-300" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900">Sua nuvem está vazia</h3>
                    <p className="text-gray-500">Arquivos enviados nos catálogos aparecerão aqui.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Viewer Modal */}
      {selectedFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-6xl h-[90vh] rounded-3xl overflow-hidden flex flex-col shadow-2xl">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">{selectedFile.name}</h3>
                  <p className="text-xs text-gray-500 capitalize">{selectedFile.contentType || 'Arquivo'}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <a 
                  href={selectedFile.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                  title="Abrir em nova aba"
                >
                  <ExternalLink className="w-5 h-5" />
                </a>
                <button 
                  onClick={() => setSelectedFile(null)}
                  className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            <div className="flex-1 bg-gray-50 overflow-auto">
              {selectedFile.contentType?.includes('image') ? (
                <div className="w-full h-full flex items-center justify-center p-8">
                  <img 
                    src={selectedFile.url} 
                    alt={selectedFile.name} 
                    className="max-w-full max-h-full object-contain rounded-lg shadow-lg"
                    referrerPolicy="no-referrer"
                  />
                </div>
              ) : selectedFile.contentType?.includes('pdf') ? (
                <iframe 
                  src={selectedFile.url} 
                  className="w-full h-full border-none"
                  title={selectedFile.name}
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center">
                  <div className="p-6 bg-white rounded-3xl shadow-sm border border-gray-100 max-w-md">
                    {getFileIcon(selectedFile.contentType)}
                    <h4 className="text-xl font-bold text-gray-900 mt-4">Visualização Indisponível</h4>
                    <p className="text-gray-500 mt-2">
                      Este tipo de arquivo não pode ser visualizado diretamente no navegador. 
                      Por favor, faça o download para visualizar.
                    </p>
                    <a 
                      href={selectedFile.url}
                      className="mt-6 inline-block bg-blue-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-700 transition-all"
                    >
                      Baixar Arquivo
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
