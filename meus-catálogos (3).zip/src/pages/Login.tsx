import { useState } from 'react';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { User, ShieldCheck, ShoppingBag } from 'lucide-react';

export default function Login() {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleGoogleLogin = async (role: 'rep' | 'client') => {
    setLoading(true);
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const docRef = doc(db, 'users', user.uid);
      const docSnap = await getDoc(docRef);
      
      const username = user.email?.split('@')[0].replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      if (!docSnap.exists()) {
        await setDoc(docRef, {
          uid: user.uid,
          email: user.email,
          name: user.displayName,
          role: role,
          username: role === 'rep' ? username : null,
          createdAt: new Date().toISOString()
        });
        toast.success(`Conta de ${role === 'rep' ? 'Representante' : 'Cliente'} criada com sucesso!`);
      } else {
        const existingData = docSnap.data();
        if (existingData.role === 'rep' && !existingData.username) {
          await setDoc(docRef, { username }, { merge: true });
        }
        toast.success('Bem-vindo de volta!');
      }
      
      navigate('/');
    } catch (error) {
      console.error(error);
      toast.error('Erro ao fazer login. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 min-h-[80vh] flex items-center justify-center">
      <div className="max-w-md w-full bg-white p-10 rounded-[2.5rem] shadow-2xl border border-gray-100">
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-navy text-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl rotate-3">
            <User className="w-10 h-10" />
          </div>
          <h1 className="text-4xl font-black text-navy tracking-tighter uppercase mb-2">Bem-vindo</h1>
          <p className="text-gray-500 font-medium tracking-tight">Escolha como deseja acessar a plataforma</p>
        </div>

        <div className="space-y-6">
          <button
            onClick={() => handleGoogleLogin('rep')}
            disabled={loading}
            className="w-full flex items-center justify-center gap-4 bg-navy text-white py-5 rounded-2xl font-bold hover:bg-blue-900 transition-all disabled:opacity-50 shadow-xl uppercase tracking-widest text-sm"
          >
            <ShieldCheck className="w-6 h-6" />
            <span>Entrar como Representante</span>
          </button>

          <div className="relative py-4">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-100"></div>
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="px-4 bg-white text-gray-400 font-bold uppercase tracking-[0.3em]">ou</span>
            </div>
          </div>

          <button
            onClick={() => handleGoogleLogin('client')}
            disabled={loading}
            className="w-full flex items-center justify-center gap-4 bg-white text-navy border-2 border-gray-100 py-5 rounded-2xl font-bold hover:bg-gray-50 transition-all disabled:opacity-50 uppercase tracking-widest text-sm"
          >
            <ShoppingBag className="w-6 h-6" />
            <span>Entrar como Cliente</span>
          </button>
        </div>
      </div>

      <p className="mt-8 text-center text-xs text-gray-400">
        Ao entrar, você concorda com nossos termos de uso e política de privacidade.
      </p>
    </div>
  );
}
