import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { Catalog, UserProfile } from '../types';
import { toast } from 'sonner';
import { BookOpen, FileText, Table, ExternalLink, Search as SearchIcon, User, Copy, X, Image as ImageIcon, Globe } from 'lucide-react';

export default function RepCatalog() {
  const { username } = useParams<{ username: string }>();
  const [rep, setRep] = useState<UserProfile | null>(null);
  const [catalogs, setCatalogs] = useState<Catalog[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCatalog, setSelectedCatalog] = useState<Catalog | null>(null);

  const copyToClipboard = (url: string) => {
    navigator.clipboard.writeText(url);
    toast.success('Link do catálogo copiado!');
  };

  useEffect(() => {
    fetchRepAndCatalogs();
  }, [username]);

  const fetchRepAndCatalogs = async () => {
    try {
      // 1. Find representative by username
      const userQ = query(collection(db, 'users'), where('username', '==', username), limit(1));
      const userSnap = await getDocs(userQ);
      
      if (userSnap.empty) {
        toast.error('Representante não encontrado.');
        setLoading(false);
        return;
      }

      const repData = { uid: userSnap.docs[0].id, ...userSnap.docs[0].data() } as UserProfile;
      setRep(repData);

      // 2. Fetch their catalogs
      const catalogQ = query(collection(db, 'catalogs'), where('repId', '==', repData.uid));
      const catalogSnap = await getDocs(catalogQ);
      setCatalogs(catalogSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Catalog)));
    } catch (error) {
      console.error(error);
      toast.error('Erro ao carregar catálogos.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex items-center justify-center h-screen text-gray-500">Carregando catálogos de {username}...</div>;

  if (!rep) return (
    <div className="text-center py-20">
      <h1 className="text-2xl font-bold text-gray-900">Representante não encontrado</h1>
      <Link to="/" className="text-blue-600 hover:underline mt-4 inline-block">Voltar para o início</Link>
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-12 space-y-12">
      <div className="bg-navy p-10 rounded-[2.5rem] shadow-2xl text-white flex flex-col md:flex-row items-center gap-8 border border-white/10">
        <div className="w-24 h-24 bg-white/10 backdrop-blur-md rounded-3xl flex items-center justify-center text-white shadow-inner border border-white/20">
          <User className="w-12 h-12" />
        </div>
        <div className="text-center md:text-left">
          <h1 className="text-5xl font-black tracking-tighter uppercase">{rep.name}</h1>
          <p className="text-blue-100 mt-1 text-xl font-light">Catálogos de Venda Exclusivos</p>
          <div className="mt-6 flex flex-wrap justify-center md:justify-start gap-3">
            <span className="px-4 py-1.5 bg-white/10 text-white rounded-full text-xs font-bold uppercase tracking-widest border border-white/20 backdrop-blur-sm">Representante Autorizado</span>
            <span className="px-4 py-1.5 bg-blue-500/20 text-blue-100 rounded-full text-xs font-bold uppercase tracking-widest border border-blue-400/30 backdrop-blur-sm">{catalogs.length} Catálogos</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
        {catalogs.map((catalog) => (
          <div key={catalog.id} className="group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100">
            <div 
              className="aspect-[3/4] overflow-hidden bg-gray-100 cursor-pointer"
              onClick={() => setSelectedCatalog(catalog)}
            >
              <img
                src={catalog.coverUrl || `https://picsum.photos/seed/${catalog.name}/400/600`}
                alt={catalog.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              {catalog.logoUrl && (
                <div className="absolute top-4 right-4 w-12 h-12 bg-white rounded-lg shadow-md p-1 flex items-center justify-center overflow-hidden z-10">
                  <img src={catalog.logoUrl} alt="Logo" className="max-w-full max-h-full object-contain" referrerPolicy="no-referrer" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
                <a
                  href={catalog.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="flex items-center justify-center gap-2 bg-white text-gray-900 py-3 rounded-xl font-bold hover:bg-blue-50 transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  Abrir no Site
                </a>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    copyToClipboard(catalog.fileUrl);
                  }}
                  className="mt-2 flex items-center justify-center gap-2 bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors"
                >
                  <Copy className="w-4 h-4" />
                  Copiar Link
                </button>
              </div>
            </div>
            <div className="p-5">
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-1 rounded-md ${
                  catalog.type === 'pdf' ? 'bg-red-50 text-red-600' : 
                  catalog.type === 'excel' ? 'bg-green-50 text-green-600' : 
                  catalog.type === 'image' ? 'bg-purple-50 text-purple-600' :
                  'bg-blue-50 text-blue-600'
                }`}>
                  {catalog.type === 'pdf' ? <FileText className="w-3 h-3 inline mr-1" /> : 
                   catalog.type === 'excel' ? <Table className="w-3 h-3 inline mr-1" /> : 
                   catalog.type === 'image' ? <ImageIcon className="w-3 h-3 inline mr-1" /> :
                   <Globe className="w-3 h-3 inline mr-1" />}
                  {catalog.type}
                </span>
                <span className="text-xs text-gray-400">{new Date(catalog.createdAt).toLocaleDateString('pt-BR')}</span>
              </div>
              <h3 className="text-lg font-bold text-gray-900 line-clamp-1">{catalog.name}</h3>
              <div className="mt-4 flex items-center justify-between">
                <Link to={`/search?catalogId=${catalog.id}`} className="text-sm font-medium text-blue-600 hover:text-blue-700 flex items-center gap-1">
                  <SearchIcon className="w-4 h-4" />
                  Buscar Produtos
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Viewer Modal */}
      {selectedCatalog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-6xl h-[90vh] rounded-3xl overflow-hidden flex flex-col shadow-2xl">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">{selectedCatalog.name}</h3>
                  <p className="text-xs text-gray-500 capitalize">{selectedCatalog.type}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <a 
                  href={selectedCatalog.fileUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                  title="Abrir em nova aba"
                >
                  <ExternalLink className="w-5 h-5" />
                </a>
                <button 
                  onClick={() => setSelectedCatalog(null)}
                  className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            <div className="flex-1 bg-gray-50 overflow-auto">
              {selectedCatalog.type === 'image' ? (
                <div className="w-full h-full flex items-center justify-center p-8">
                  <img 
                    src={selectedCatalog.fileUrl} 
                    alt={selectedCatalog.name} 
                    className="max-w-full max-h-full object-contain rounded-lg shadow-lg"
                    referrerPolicy="no-referrer"
                  />
                </div>
              ) : selectedCatalog.type === 'pdf' || selectedCatalog.type === 'external' ? (
                <iframe 
                  src={selectedCatalog.fileUrl} 
                  className="w-full h-full border-none"
                  title={selectedCatalog.name}
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center">
                  <Table className="w-16 h-16 text-green-600 mb-4" />
                  <h4 className="text-xl font-bold text-gray-900">Visualização de Planilha</h4>
                  <p className="text-gray-500 mt-2 max-w-md">
                    Planilhas Excel não podem ser visualizadas diretamente no navegador. 
                    Por favor, utilize a busca de produtos ou faça o download do arquivo.
                  </p>
                  <a 
                    href={selectedCatalog.fileUrl}
                    className="mt-6 bg-green-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-green-700 transition-all"
                  >
                    Baixar Planilha
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
