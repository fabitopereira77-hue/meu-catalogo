import * as XLSX from 'xlsx';
import * as pdfjsLib from 'pdfjs-dist';

// Configure PDF.js worker
// Using a more reliable CDN URL that matches the version
const PDFJS_VERSION = '4.10.38';
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${PDFJS_VERSION}/pdf.worker.min.mjs`;

export async function parseExcel(file: File): Promise<any[]> {
  try {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet);
          resolve(jsonData);
        } catch (err) {
          reject(new Error('Erro ao processar planilha Excel: ' + (err as Error).message));
        }
      };
      reader.onerror = () => reject(new Error('Erro ao ler arquivo Excel.'));
      reader.readAsArrayBuffer(file);
    });
  } catch (error) {
    throw new Error('Erro na importação Excel: ' + (error as Error).message);
  }
}

export async function parsePDF(file: File): Promise<string[]> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const loadingTask = pdfjsLib.getDocument({ 
      data: arrayBuffer,
      useSystemFonts: true,
      disableFontFace: false
    });
    
    const pdf = await loadingTask.promise;
    const textContent: string[] = [];

    for (let i = 1; i <= pdf.numPages; i++) {
      try {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        const strings = content.items.map((item: any) => item.str);
        textContent.push(strings.join(' '));
      } catch (pageErr) {
        console.warn(`Erro ao ler página ${i}:`, pageErr);
        textContent.push(`[Erro na página ${i}]`);
      }
    }

    return textContent;
  } catch (error) {
    console.error('Erro no parsePDF:', error);
    throw new Error('Erro ao processar PDF: ' + (error as Error).message);
  }
}
