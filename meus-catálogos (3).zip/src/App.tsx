import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Toaster } from 'sonner';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Search from './pages/Search';
import Quote from './pages/Quote';
import Login from './pages/Login';
import RepCatalog from './pages/RepCatalog';
import ClientQuote from './pages/ClientQuote';
import Cloud from './pages/Cloud';

import { MessageCircle } from 'lucide-react';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex items-center justify-center h-screen">Carregando...</div>;
  return user ? <>{children}</> : <Navigate to="/login" />;
}

function AppContent() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main className="min-h-screen">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/search" element={<Search />} />
          <Route path="/quote" element={<PrivateRoute><Quote /></PrivateRoute>} />
          <Route path="/login" element={<Login />} />
          <Route path="/MeusCatalogos/:username" element={<RepCatalog />} />
          <Route path="/client/quote/:quoteId" element={<ClientQuote />} />
          <Route path="/cloud" element={<PrivateRoute><Cloud /></PrivateRoute>} />
        </Routes>
      </main>
      
      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/5500000000000"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-8 right-8 bg-[#25D366] text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform z-50 flex items-center justify-center"
        title="Fale conosco no WhatsApp"
      >
        <MessageCircle className="w-8 h-8" />
      </a>
      
      <Toaster position="top-right" />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}
